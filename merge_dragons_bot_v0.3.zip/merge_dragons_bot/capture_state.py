\
from __future__ import annotations

import argparse
import datetime as dt

import cv2

from adb import ADB
from config import LOGS


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "name",
        help="Short label such as world_map, level, reward, popup, camp_zoom2",
    )
    args = parser.parse_args()

    adb = ADB()
    adb.ensure_device()
    frame = adb.screenshot()

    LOGS.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    safe = "".join(c for c in args.name if c.isalnum() or c in "_-")
    path = LOGS / f"state_{safe}_{stamp}.png"
    cv2.imwrite(str(path), frame)
    print(path)


if __name__ == "__main__":
    main()
