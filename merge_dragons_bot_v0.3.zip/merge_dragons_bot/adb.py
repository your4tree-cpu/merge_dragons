\
from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from config import BotConfig


class ADBError(RuntimeError):
    pass


@dataclass
class DeviceInfo:
    serial: str
    state: str


class ADB:
    def __init__(self, config: BotConfig | None = None):
        self.config = config or BotConfig()

    def _run(self, *args: str, binary: bool = False, timeout: float | None = None):
        cmd = [self.config.adb_path, *args]
        try:
            return subprocess.run(
                cmd,
                check=True,
                capture_output=True,
                text=not binary,
                timeout=timeout or self.config.screenshot_timeout,
            )
        except FileNotFoundError as e:
            raise ADBError(
                "adb was not found. Install Android platform-tools and make sure adb.exe is on PATH."
            ) from e
        except subprocess.CalledProcessError as e:
            msg = e.stderr if isinstance(e.stderr, str) else repr(e.stderr)
            raise ADBError(f"ADB command failed: {' '.join(cmd)}\n{msg}") from e

    def devices(self) -> list[DeviceInfo]:
        out = self._run("devices").stdout.splitlines()[1:]
        devices = []
        for line in out:
            if not line.strip():
                continue
            parts = line.split()
            if len(parts) >= 2:
                devices.append(DeviceInfo(parts[0], parts[1]))
        return devices

    def ensure_device(self) -> DeviceInfo:
        devices = [d for d in self.devices() if d.state == "device"]
        if not devices:
            raise ADBError(
                "No authorized Android device found. Connect USB, enable USB debugging, "
                "and accept the authorization prompt on the phone."
            )
        return devices[0]

    def shell(self, *args: str) -> str:
        return self._run("shell", *args).stdout.strip()

    def launch_game(self) -> None:
        # Monkey asks Android to launch the package's normal launcher activity.
        self._run(
            "shell", "monkey", "-p", self.config.package,
            "-c", "android.intent.category.LAUNCHER", "1",
            timeout=15,
        )

    def stop_game(self) -> None:
        self.shell("am", "force-stop", self.config.package)

    def screenshot(self) -> np.ndarray:
        result = self._run("exec-out", "screencap", "-p", binary=True)
        raw = np.frombuffer(result.stdout, dtype=np.uint8)
        frame = cv2.imdecode(raw, cv2.IMREAD_COLOR)
        if frame is None:
            raise ADBError("Could not decode the screenshot returned by ADB.")
        return frame

    def save_screenshot(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        frame = self.screenshot()
        if not cv2.imwrite(str(path), frame):
            raise ADBError(f"Could not save screenshot to {path}")
        return path

    def tap(self, x: int, y: int) -> None:
        self.shell("input", "tap", str(int(x)), str(int(y)))

    def swipe(self, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 350) -> None:
        self.shell(
            "input", "swipe",
            str(int(x1)), str(int(y1)), str(int(x2)), str(int(y2)),
            str(int(duration_ms)),
        )

    def drag(self, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 650) -> None:
        self.swipe(x1, y1, x2, y2, duration_ms)

    def wait(self, seconds: float = 0.75) -> None:
        time.sleep(seconds)
