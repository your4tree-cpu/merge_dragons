\
from __future__ import annotations

import sys

import cv2

from adb import ADB, ADBError
from config import LOGS
from vision import Vision


def main() -> int:
    adb = ADB()
    vision = Vision()

    try:
        device = adb.ensure_device()
        print(f"[OK] device: {device.serial} ({device.state})")

        size = adb.shell("wm", "size")
        print(f"[OK] {size}")

        package_line = adb.shell(
            "pm", "path", "com.gramgames.mergedragons"
        )
        if package_line:
            print("[OK] Merge Dragons package is installed")
        else:
            print("[WARN] Merge Dragons package was not found")

        LOGS.mkdir(parents=True, exist_ok=True)
        frame = adb.screenshot()
        path = LOGS / "diagnostic.png"
        cv2.imwrite(str(path), frame)
        print(f"[OK] screenshot: {frame.shape[1]}x{frame.shape[0]} -> {path}")

        d = vision.detect(frame)
        print(f"[OK] detected state: {d.state.value}")
        print(f"[OK] confidence: {d.confidence:.3f}")
        for name, score in d.scores.items():
            print(f"     {name:12s} {score:.3f}")

        return 0
    except ADBError as e:
        print(f"[FAIL] {e}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
