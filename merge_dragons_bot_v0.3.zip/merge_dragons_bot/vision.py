\
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

import cv2
import numpy as np

from config import CANONICAL_HEIGHT, CANONICAL_WIDTH, REFS


class GameState(str, Enum):
    CAMP = "camp"
    WORLD_MAP_SELECTED = "world_map_selected"
    LEVEL_TUTORIAL = "level_tutorial"
    UNKNOWN = "unknown"


@dataclass
class Detection:
    state: GameState
    confidence: float
    scores: dict[str, float]


class Vision:
    def __init__(self, refs: Path = REFS):
        self.refs = refs

        self.camp_templates = {
            "camp_map": self._load_gray("camp_map_icon.png"),
            "camp_friends": self._load_gray("camp_friends_icon.png"),
            "camp_shop": self._load_gray("camp_shop_icon.png"),
            "camp_screen_drag": self._load_gray("camp_screen_drag.png"),
        }
        self.camp_rois = {
            "camp_map": (83, 12, 151, 74),
            "camp_friends": (1530, 452, 1591, 505),
            "camp_shop": (1531, 533, 1590, 592),
            "camp_screen_drag": (1490, 610, 1603, 719),
        }

        self.world_templates = {
            "world_home": self._load_gray("world_home_icon.png"),
            "world_play": self._load_gray("world_play_button.png"),
            "world_header": self._load_gray("world_panel_header.png"),
            "world_chest": self._load_gray("world_chest_icon.png"),
        }
        self.world_rois = {
            "world_home": (75, 610, 175, 718),
            "world_play": (1220, 590, 1555, 700),
            "world_header": (1150, 0, 1590, 105),
            "world_chest": (98, 10, 180, 80),
        }

        self.tutorial_templates = {
            "tutorial_header": self._load_gray("tutorial_header.png"),
            "tutorial_next": self._load_gray("tutorial_next_arrow.png"),
            "level_back": self._load_gray("level_back_button.png"),
        }
        self.tutorial_rois = {
            "tutorial_header": (350, 370, 1235, 455),
            "tutorial_next": (1165, 485, 1265, 650),
            "level_back": (75, 0, 165, 85),
        }

    def _load_gray(self, filename: str) -> np.ndarray:
        image = cv2.imread(str(self.refs / filename), cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise FileNotFoundError(self.refs / filename)
        return image

    @staticmethod
    def normalize(frame: np.ndarray) -> np.ndarray:
        if frame.shape[1] == CANONICAL_WIDTH and frame.shape[0] == CANONICAL_HEIGHT:
            return frame
        return cv2.resize(
            frame,
            (CANONICAL_WIDTH, CANONICAL_HEIGHT),
            interpolation=cv2.INTER_AREA,
        )

    @staticmethod
    def _similarity(roi_bgr: np.ndarray, template_gray: np.ndarray) -> float:
        roi_gray = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2GRAY)
        if roi_gray.shape != template_gray.shape:
            roi_gray = cv2.resize(
                roi_gray,
                (template_gray.shape[1], template_gray.shape[0]),
                interpolation=cv2.INTER_AREA,
            )
        score = cv2.matchTemplate(
            roi_gray, template_gray, cv2.TM_CCOEFF_NORMED
        )[0, 0]
        if np.isnan(score):
            return 0.0
        return float(np.clip(score, -1.0, 1.0))

    def _score_group(self, frame, rois, templates):
        scores = {}
        for name, (x1, y1, x2, y2) in rois.items():
            scores[name] = self._similarity(frame[y1:y2, x1:x2], templates[name])
        return scores

    @staticmethod
    def _top_mean(scores: dict[str, float], count: int = 3) -> float:
        vals = sorted(scores.values(), reverse=True)
        return float(sum(vals[:min(count, len(vals))]) / min(count, len(vals)))

    def detect(self, frame: np.ndarray) -> Detection:
        frame = self.normalize(frame)

        tutorial = self._score_group(frame, self.tutorial_rois, self.tutorial_templates)
        world = self._score_group(frame, self.world_rois, self.world_templates)
        camp = self._score_group(frame, self.camp_rois, self.camp_templates)

        tutorial_conf = self._top_mean(tutorial, 3)
        world_conf = self._top_mean(world, 3)
        camp_conf = self._top_mean(camp, 3)

        # Tutorial is most specific and is checked first.
        if (
            tutorial_conf >= 0.82
            and tutorial["tutorial_header"] >= 0.80
            and tutorial["tutorial_next"] >= 0.76
        ):
            return Detection(GameState.LEVEL_TUTORIAL, tutorial_conf, tutorial)

        if world_conf >= 0.82 and sum(v >= 0.76 for v in world.values()) >= 2:
            return Detection(GameState.WORLD_MAP_SELECTED, world_conf, world)

        if camp_conf >= 0.78 and sum(v >= 0.70 for v in camp.values()) >= 2:
            return Detection(GameState.CAMP, camp_conf, camp)

        groups = [
            (tutorial_conf, tutorial),
            (world_conf, world),
            (camp_conf, camp),
        ]
        conf, scores = max(groups, key=lambda x: x[0])
        return Detection(GameState.UNKNOWN, conf, scores)

    @staticmethod
    def frame_change(before: np.ndarray, after: np.ndarray) -> float:
        before = Vision.normalize(before)
        after = Vision.normalize(after)
        a = cv2.cvtColor(before, cv2.COLOR_BGR2GRAY).astype(np.float32)
        b = cv2.cvtColor(after, cv2.COLOR_BGR2GRAY).astype(np.float32)
        return float(np.mean(np.abs(a - b)) / 255.0)
