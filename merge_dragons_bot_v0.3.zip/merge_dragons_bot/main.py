\
from __future__ import annotations

import argparse

from adb import ADB
from bot import MergeDragonsBot


def main():
    parser = argparse.ArgumentParser(description="Merge Dragons ADB automation")
    parser.add_argument(
        "mode",
        choices=[
            "launch",
            "observe",
            "run",
            "enter-selected",
            "clear-tutorial",
        ],
        help=(
            "launch, observe, run current planner, enter the selected level once, "
            "or advance only the recognized Quests tutorial pager"
        ),
    )
    args = parser.parse_args()

    if args.mode == "launch":
        adb = ADB()
        adb.ensure_device()
        adb.launch_game()
        print("Launch command sent.")
        return

    bot = MergeDragonsBot()
    bot.adb.ensure_device()

    if args.mode == "observe":
        bot.observe_loop()
    elif args.mode == "run":
        bot.run()
    elif args.mode == "enter-selected":
        bot.enter_selected_level()
    elif args.mode == "clear-tutorial":
        bot.clear_quest_tutorial()


if __name__ == "__main__":
    main()
