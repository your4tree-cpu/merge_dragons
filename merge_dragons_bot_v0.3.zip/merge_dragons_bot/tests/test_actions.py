\
import pytest

from actions import Actions, ProtectedTapError
from config import BotConfig


class FakeADB:
    def __init__(self):
        self.config = BotConfig()


def test_coordinate_scaling_identity():
    a = Actions(FakeADB())
    assert a.canonical_to_device(802, 360, 1604, 720) == (802, 360)


def test_coordinate_scaling_double():
    a = Actions(FakeADB())
    assert a.canonical_to_device(802, 360, 3208, 1440) == (1604, 720)


def test_premium_area_is_protected():
    a = Actions(FakeADB())
    with pytest.raises(ProtectedTapError):
        a._guard(1500, 35)
