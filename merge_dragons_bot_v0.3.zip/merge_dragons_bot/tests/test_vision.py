\
from pathlib import Path

import cv2

from vision import GameState, Vision


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures"


def read(name: str):
    frame = cv2.imread(str(FIXTURES / name))
    assert frame is not None
    return frame


def test_original_reference_detects_camp():
    frame = cv2.imread(str(ROOT / "refs" / "camp_reference.png"))
    assert frame is not None
    result = Vision().detect(frame)
    assert result.state == GameState.CAMP
    assert result.confidence >= 0.95


def test_live_camp_variant_detects_camp():
    result = Vision().detect(read("camp_live.png"))
    assert result.state == GameState.CAMP
    assert result.confidence >= 0.90


def test_all_three_world_map_animation_variants_detect():
    vision = Vision()
    for name in [
        "world_map_variant_a.png",
        "world_map_variant_b.png",
        "world_map_variant_c.png",
    ]:
        result = vision.detect(read(name))
        assert result.state == GameState.WORLD_MAP_SELECTED, (name, result)
        assert result.confidence >= 0.88, (name, result)


def test_level_tutorial_page1_detects():
    result = Vision().detect(read("level_tutorial_page1.png"))
    assert result.state == GameState.LEVEL_TUTORIAL
    assert result.confidence >= 0.95
    assert result.scores["tutorial_header"] >= 0.95
    assert result.scores["tutorial_next"] >= 0.95


def test_frame_change_identical_is_zero():
    frame = read("world_map_variant_a.png")
    assert Vision.frame_change(frame, frame.copy()) == 0.0


def test_world_map_variants_are_not_pixel_identical():
    a = read("world_map_variant_a.png")
    b = read("world_map_variant_b.png")
    assert Vision.frame_change(a, b) > 0.0
