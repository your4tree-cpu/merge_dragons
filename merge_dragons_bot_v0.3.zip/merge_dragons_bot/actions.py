\
from __future__ import annotations

import time

from adb import ADB
from config import (
    BotConfig,
    CANONICAL_HEIGHT,
    CANONICAL_WIDTH,
    PROTECTED_RECTS,
)
from vision import Vision


class ProtectedTapError(RuntimeError):
    pass


class Actions:
    def __init__(self, adb: ADB, config: BotConfig | None = None):
        self.adb = adb
        self.config = config or adb.config

    @staticmethod
    def canonical_to_device(x: int, y: int, frame_width: int, frame_height: int):
        return (
            round(x * frame_width / CANONICAL_WIDTH),
            round(y * frame_height / CANONICAL_HEIGHT),
        )

    @staticmethod
    def _in_rect(x: int, y: int, rect) -> bool:
        x1, y1, x2, y2 = rect
        return x1 <= x < x2 and y1 <= y < y2

    def _guard(self, x: int, y: int) -> None:
        if self.config.allow_protected_taps:
            return
        for rect in PROTECTED_RECTS:
            if self._in_rect(x, y, rect):
                raise ProtectedTapError(
                    f"Blocked tap at canonical ({x}, {y}) because it falls in a "
                    "protected premium/store area."
                )

    def tap_canonical(self, x: int, y: int, verify_change: bool = False) -> float | None:
        self._guard(x, y)
        before = self.adb.screenshot() if verify_change else None
        h, w = (before.shape[:2] if before is not None else self.adb.screenshot().shape[:2])
        dx, dy = self.canonical_to_device(x, y, w, h)
        self.adb.tap(dx, dy)
        if not verify_change:
            return None
        time.sleep(0.75)
        after = self.adb.screenshot()
        return Vision.frame_change(before, after)

    def drag_canonical(
        self,
        x1: int, y1: int, x2: int, y2: int,
        duration_ms: int = 650,
        verify_change: bool = False,
    ) -> float | None:
        self._guard(x1, y1)
        self._guard(x2, y2)
        before = self.adb.screenshot()
        h, w = before.shape[:2]
        a = self.canonical_to_device(x1, y1, w, h)
        b = self.canonical_to_device(x2, y2, w, h)
        self.adb.drag(*a, *b, duration_ms)
        if not verify_change:
            return None
        time.sleep(0.9)
        after = self.adb.screenshot()
        return Vision.frame_change(before, after)
