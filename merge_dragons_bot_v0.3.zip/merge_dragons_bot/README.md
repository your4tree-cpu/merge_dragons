# Merge Dragons ADB Bot

Version 0.3, calibrated from live 1604x720 captures.

## Recognized states

- `camp`
- `world_map_selected`
- `level_tutorial`
- `unknown`

The latest capture is a real in-level screen with the four-page **Quests**
tutorial dialog covering the board. Version 0.3 recognizes that overlay
separately.

## Setup

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
adb devices
python diagnose.py
```

## Passive recognition

```powershell
python main.py observe
```

No taps are sent.

## Enter a selected level

From a world-map screen with the green Play button visible:

```powershell
python main.py enter-selected
```

## Clear only the recognized Quests tutorial

With the centered Quests dialog visible:

```powershell
python main.py clear-tutorial
```

This command does **not** blindly tap four times. Before every tap it captures a
fresh screenshot and requires the quest/tutorial dialog to still be recognized.
As soon as the dialog disappears, it stops clicking and saves:

```text
logs\after_tutorial_*.png
```

Send that resulting screenshot back. It should expose the underlying playable
board or the next tutorial instruction, which is what the next solver stage
needs.

The command has a six-tap safety limit.

## Tests

```powershell
pytest -q
```

Premium-currency and store tap protection remains enabled.
