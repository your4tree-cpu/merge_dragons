from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFS = ROOT / "refs"
LOGS = ROOT / "logs"

PACKAGE = "com.gramgames.mergedragons"
CANONICAL_WIDTH = 1604
CANONICAL_HEIGHT = 720

# Coordinates in this project are stored in canonical screenshot space.
# They are scaled to the actual device screenshot automatically.
PROTECTED_RECTS = [
    # Premium currency / add-currency area.
    (1280, 0, 1604, 105),
    # Right-side store button area.
    (1515, 520, 1604, 610),
]

@dataclass(frozen=True)
class BotConfig:
    adb_path: str = "adb"
    package: str = PACKAGE
    screenshot_timeout: float = 8.0
    poll_interval: float = 1.0
    allow_protected_taps: bool = False
