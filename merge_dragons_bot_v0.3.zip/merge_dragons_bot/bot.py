\
from __future__ import annotations

import datetime as dt
import time

import cv2

from adb import ADB
from actions import Actions
from config import BotConfig, LOGS
from vision import GameState, Vision


class MergeDragonsBot:
    def __init__(self, config: BotConfig | None = None):
        self.config = config or BotConfig()
        self.adb = ADB(self.config)
        self.vision = Vision()
        self.actions = Actions(self.adb, self.config)
        LOGS.mkdir(parents=True, exist_ok=True)

    def observe_once(self):
        frame = self.adb.screenshot()
        detection = self.vision.detect(frame)
        return frame, detection

    def observe_loop(self):
        print("Observer running. Ctrl+C stops it. No taps will be sent.")
        try:
            while True:
                _, detection = self.observe_once()
                score_text = ", ".join(
                    f"{k}={v:.3f}" for k, v in detection.scores.items()
                )
                print(
                    f"state={detection.state.value:<20} "
                    f"confidence={detection.confidence:.3f} | {score_text}"
                )
                time.sleep(self.config.poll_interval)
        except KeyboardInterrupt:
            print("\nStopped.")

    def _save_frame(self, frame, prefix: str):
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        path = LOGS / f"{prefix}_{stamp}.png"
        cv2.imwrite(str(path), frame)
        return path

    def save_unknown(self, frame):
        return self._save_frame(frame, "unknown")

    def enter_selected_level(self):
        before, detection = self.observe_once()
        if detection.state != GameState.WORLD_MAP_SELECTED:
            raise RuntimeError(
                "Expected a selected level on the world map, but detected "
                f"{detection.state.value} ({detection.confidence:.3f})."
            )

        print(f"Selected level detected. confidence={detection.confidence:.3f}")

        change = self.actions.tap_canonical(1388, 646, verify_change=True)
        print(f"Immediate frame-change score after Play tap: {change:.4f}")

        time.sleep(4.0)
        after, after_detection = self.observe_once()
        path = self._save_frame(after, "after_play")

        print(
            f"After Play: state={after_detection.state.value}, "
            f"confidence={after_detection.confidence:.3f}"
        )
        print(f"Captured: {path}")
        return path, after_detection

    def clear_quest_tutorial(self, max_pages: int = 6):
        """
        Advance only the centered Quests pager.

        Every tap is gated by fresh visual recognition. The method stops as soon
        as the tutorial pager is no longer detected, then captures the resulting
        board/state for the next training step.
        """
        print("Clearing recognized quest tutorial pages...")
        pages = 0

        while pages < max_pages:
            frame, detection = self.observe_once()

            if detection.state != GameState.LEVEL_TUTORIAL:
                path = self._save_frame(frame, "after_tutorial")
                print(
                    f"Tutorial no longer detected after {pages} page tap(s). "
                    f"Current state={detection.state.value}, "
                    f"confidence={detection.confidence:.3f}"
                )
                print(f"Captured: {path}")
                return path, detection

            before_path = self._save_frame(frame, f"tutorial_page_{pages + 1}")
            print(
                f"page {pages + 1}: confidence={detection.confidence:.3f} "
                f"saved={before_path.name}"
            )

            # Center of the gold right-arrow on the quest dialog.
            change = self.actions.tap_canonical(1210, 565, verify_change=True)
            print(f"  arrow tap frame-change={change:.4f}")
            pages += 1
            time.sleep(0.8)

        frame, detection = self.observe_once()
        path = self._save_frame(frame, "tutorial_limit")
        print(
            f"Stopped at safety limit ({max_pages} taps). "
            f"state={detection.state.value}, confidence={detection.confidence:.3f}"
        )
        print(f"Captured: {path}")
        return path, detection

    def run(self):
        print("Bot runner started. Ctrl+C stops it.")
        last_unknown_save = 0.0
        try:
            while True:
                frame, detection = self.observe_once()

                if detection.state == GameState.CAMP:
                    print(f"CAMP {detection.confidence:.3f}")
                elif detection.state == GameState.WORLD_MAP_SELECTED:
                    print(f"WORLD_MAP_SELECTED {detection.confidence:.3f}")
                elif detection.state == GameState.LEVEL_TUTORIAL:
                    print(f"LEVEL_TUTORIAL {detection.confidence:.3f}")
                else:
                    now = time.time()
                    print(f"UNKNOWN {detection.confidence:.3f}")
                    if now - last_unknown_save > 8:
                        path = self.save_unknown(frame)
                        print(f"saved {path}")
                        last_unknown_save = now

                time.sleep(self.config.poll_interval)
        except KeyboardInterrupt:
            print("\nStopped.")
